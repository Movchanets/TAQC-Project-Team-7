import{a}from"./chunk-47CS2OCG.js";import"./chunk-GJ7P76DY.js";export default a();
